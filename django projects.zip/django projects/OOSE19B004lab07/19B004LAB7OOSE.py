
from flask import Flask,jsonify,render_template,request
app=Flask(__name__,template_folder='templates')
data=[
        {"empid":1,"name":"Ram","email":"ram@gmail.com","age":23},
        {"empid":2,"name":"Shyam","email":"shyam23@gmail.com","age":28},
        {"empid":3,"name":"John","email":"john@gmail.com","age":33},
        {"empid":4,"name":"Bob","email":"bob32@gmail.com","age":41}
    ]
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/showall')
def showall():
    return jsonify(data)

@app.route('/show')
def show():
    id=int(request.args['id'])
    detail=[]
    for emp in data:
        if emp['empid']==id:
            detail.append(emp)
    return jsonify(detail)

if __name__=='__main__':
    app.run(debug=True)

from flask import Flask
from flask_restful import reqparse, abort, Api, Resource
import json

app=Flask(__name__)
api=Api(app)
TODOS=json.load(open("scratch.json"))

def abort_if_todo_doesnot_exists(todo_id):
    if todo_id not in TODOS:
        abort(404,message="Todo {} doesn't exists".format(todo_id))

parsaer = reqparse.RequestParser()
parsaer.add_argument('number')

class Todo(Resource):
    def get(self, todo_id):
        abort_if_todo_doesnot_exists(todo_id)
        return TODOS[todo_id]
    def delete(self, todo_id):
        abort_if_todo_doesnot_exists(todo_id)
        del TODOS[todo_id]
        return '', 204
    def put(self,todo_id):
        args = parsaer.parse_args()
        task={'number': args['number']}
        TODOS[todo_id]=task
        return task, 201
class TodoList(Resource):
    def get(self):
        return TODOS
    def post(self):
        args=parsaer.parse_args()
        todo_id=str(int(max(TODOS.keys()).lstrip('todo')) +2)
        TODOS[todo_id]={'number': args['number']}
        return TODOS[todo_id], 201
api.add_resource(TodoList,'/todos')
api.add_resource(Todo, '/todos/<todo_id>')

if __name__=='__main__':
    app.run(debug=True)

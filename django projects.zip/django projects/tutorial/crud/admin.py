from django.contrib import admin

from .models import Projects, Students

admin.site.register(Projects)
admin.site.register(Students)

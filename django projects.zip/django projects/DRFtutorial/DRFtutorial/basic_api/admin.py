from django.contrib import admin

from basic_api.models import DRFPost

# DataFlair

admin.site.register(DRFPost)
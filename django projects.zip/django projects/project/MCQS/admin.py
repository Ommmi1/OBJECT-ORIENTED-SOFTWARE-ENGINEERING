from django.contrib import admin
from .models import *

admin.site.register(Course)
admin.site.register(Questions)
admin.site.register(Admin)

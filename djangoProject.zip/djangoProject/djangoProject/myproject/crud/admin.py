from django.contrib import admin
from .models import Project,Students

# Register your models here.

admin.site.register(Students)
admin.site.register(Project)
